# schwabentoepfle.de
 Responsive website built with HTML5, CSS, and JavaScript. Crafted with ❤️ for 'zoam Schwoabetöpfle,' a traditional Swabian restaurant.

Made with ❤️ by Shriram Govindarajan
Parent Repository URL: https://github.com/TechnoMeter/schwabentoepfle.de.github.io
